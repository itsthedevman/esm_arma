class flagStealStartedRequest
{
    module = "system_territory";

    parameters[] =
    {
        "OBJECT"
    };
};
