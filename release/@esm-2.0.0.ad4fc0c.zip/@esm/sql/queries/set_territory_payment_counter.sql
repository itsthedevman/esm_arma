UPDATE
    territory
SET
    esm_payment_counter = :counter_value
WHERE
    id = :territory_id
