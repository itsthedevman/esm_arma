DELETE FROM player
WHERE
    damage = 1
