DELETE FROM player
WHERE
    account_uid = :uid
