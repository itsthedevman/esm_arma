UPDATE
    territory
SET
    esm_custom_id = :custom_id
WHERE
    id = :territory_id
